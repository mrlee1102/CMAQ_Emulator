# import pefile

# pe = pefile.PE("D:\\c_code\\o3_model_compile\\build\\libforward.dll")
# machine = pe.FILE_HEADER.Machine
# print(hex(machine))
import struct
print(struct.calcsize("P") * 8)
